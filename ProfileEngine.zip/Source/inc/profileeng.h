#ifndef PROFILE_H
#define PROFILE_H

#include <e32std.h>
#include <e32base.h>

//Some helper macros if you want to leave profiling in the code but turn it off
#ifdef PROFILING
#define PROFILE_INIT(COUNT) CProfiler::OpenL(COUNT)
#define PROFILE_START(CAT) CProfiler::Start(CAT);
#define PROFILE_STOP(CAT) CProfiler::Stop(CAT);
#define PROFILE_SHUTDOWN(FILENAME) {CProfiler::DumpResults(FILENAME); CProfiler::Close();}
#else
#define PROFILE_INIT(COUNT)
#define PROFILE_START(CAT)
#define PROFILE_STOP(CAT)
#define PROFILE_SHUTDOWN(FILENAME)
#endif

class TProfileItem
	{
	public:
		TInt iStartTime;
		TInt iTotalTime;
	};

class CProfiler
	{
	public:
		/**
		Initialises the profiler.
		You can ask for more categories than you need, this is just to keep all memory
		allocation at startup.
		@leave KErrNoMemory
		*/
		EXPORT_C static void OpenL(TInt aNumberOfCategories);
		/**
		Frees all memory associated with the profiler.
		*/
		EXPORT_C static void Close();
		/**
		Enter a category
		This starts timing for the category.
		Calling start twice resets the timer. (client defect)
		e.g. function entry
		*/
		EXPORT_C static void Start(TInt aCategory);
		/**
		Leave a category
		This stops timing for the category, and updates the total time.
		Calling stop twice gives incorrect results. (client defect)
		e.g. function return
		*/
		EXPORT_C static void Stop(TInt aCategory);
		/**
		Save the profiling results to a file.
		Results are also output to RDebug::Print, which helps on wingboards etc.
		This can be called at any time, though it won't pause timing.
		Normal use is to call this just before Close().
		*/
		EXPORT_C static void DumpResults(const TDesC& aFileName);
		~CProfiler();
	private:
		void ConstructL(TInt aNumberOfCategories);
		static CProfiler *TheProfiler();

		enum ProfilerPanics
			{
			ENullPointer, //Caused by calling any function before OpenL
			EOpenTwice, //Caused by calling OpenL twice without a Close in between
			};

		RArray<TProfileItem> iItems;
	};

#endif // PROFILE_H
