#include <profileeng.h>
#include <f32file.h>

_LIT(KProfilerPanic, "Profiler Panic");
_LIT8(KFileHeader, "Category, Ticks\r\n");
_LIT8(KFileLine, "%d,%d\r\n");
_LIT(KDebugLine, "Category %d, Ticks %d");

TInt E32Dll(TDllReason)
	{
	return KErrNone;
	}

void CProfiler::OpenL(TInt aNumberOfCategories)
	{
	CProfiler* profiler = new(ELeave) CProfiler;
	CleanupStack::PushL(profiler);
	profiler->ConstructL(aNumberOfCategories);
	CleanupStack::Pop(profiler);
	__ASSERT_ALWAYS(Dll::Tls() == NULL, User::Panic(KProfilerPanic, EOpenTwice));
	Dll::SetTls(profiler);
	}

void CProfiler::Close()
	{
	CProfiler* profiler = TheProfiler();
	delete profiler;
	Dll::SetTls(NULL);
	}

void CProfiler::Start(TInt aCategory)
	{
	CProfiler* profiler = TheProfiler();
	profiler->iItems[aCategory].iStartTime = User::TickCount();
	}

void CProfiler::Stop(TInt aCategory)
	{
	CProfiler* profiler = TheProfiler();
	profiler->iItems[aCategory].iTotalTime += User::TickCount() - (profiler->iItems[aCategory].iStartTime);
	}

void CProfiler::DumpResults(const TDesC& aFileName)
	{
	CProfiler* profiler = TheProfiler();
	RFs fs;
	RFile file;
	TBool ok = EFalse;
	TBuf8<256> line;
	TInt err;
	err = fs.Connect();
	if(KErrNone == err)
		{
		err = file.Replace(fs, aFileName, EFileWrite);
		if(KErrNone==err)
			{
			ok = ETrue;
			}
		else
			{
			User::Panic(_L("f.replace"),err);
			fs.Close();
			}
		}
	else User::Panic(_L("f.connect"),err);
	if(ok)
		{
		file.Write(KFileHeader);
		}
	for(TInt i=0;i<profiler->iItems.Count();i++)
		{
		RDebug::Print(KDebugLine, i, profiler->iItems[i].iTotalTime);
		if(ok)
			{
			line.Format(KFileLine, i, profiler->iItems[i].iTotalTime);
			file.Write(line);
			}
		}
	if(ok)
		{
		file.Close();
		fs.Close();
		}
	}

void CProfiler::ConstructL(TInt aNumberOfCategories)
	{
	TProfileItem item;
	item.iStartTime = 0;
	item.iTotalTime = 0;
	while(aNumberOfCategories--)
		{
		User::LeaveIfError(iItems.Append(item));
		}
	}

CProfiler* CProfiler::TheProfiler()
	{
	CProfiler* profiler = (CProfiler*) Dll::Tls();
	__ASSERT_ALWAYS(profiler, User::Panic(KProfilerPanic, ENullPointer));
	return profiler;
	}

CProfiler::~CProfiler()
	{
	iItems.Close();
	}
