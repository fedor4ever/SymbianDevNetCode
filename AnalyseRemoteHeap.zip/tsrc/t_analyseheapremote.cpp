#include "analyseheapengine.h"
#include <e32test.h>
#include <e32svr.h>

enum TAnalyseHeapTextUiPanic
	{
	EProblemCreatingScheduler=0,
	EProblemFindingThreads
	};

_LIT(KLitPanic, "AnalyseHeap");

void Panic(TAnalyseHeapTextUiPanic aNum)
	{
	User::Panic(KLitPanic, aNum);
	}

#ifdef __WINS__
_LIT(KLitDirName, "c:\\");
#else
_LIT(KLitDirName, "e:\\");
#endif

void RunTestsL()
	{
	RTest test(_L("Dumping heaps"));

	test.Title();
	test.Start(_L("Creating CHeapAnalyser"));
	CHeapAnalyser* cha = NULL;
	TRAPD(err, cha = CHeapAnalyser::NewL());
	test(err == KErrNone);

	if (cha == NULL)
		return;
	if (err != KErrNone)
		return;

	TFindThread find;
	TFullName name;
	while (find.Next(name) == KErrNone && name.Length() != 0)
		{
		RThread thread;
		User::LeaveIfError(thread.Open(name));
		TInt id = thread.Id();
		test.Next(name);
		THeapDetails heapDetails;
		TRAPD(err, cha->GetHeapDetailsL(id, heapDetails));
		test.Printf(_L("Heap %d: size %d, free %d, base %08x, count %d\n"), id, heapDetails.iSize, heapDetails.FreeSpace(), heapDetails.iBase, heapDetails.iCellCount);
		TRAP(err, cha->DumpHeapToSuitableFileInDirectoryL(id, KLitDirName()));
		//test(err == KErrNone); // do not panic if it fails to dump
		// any given thread
		}

	test.Next(_L("Deleting CHeapAnalyser"));
	delete cha;
	test(1); // can't check whether that failed

	test.Printf(_L("Press a key\n"));
	test.Getch();

	test.End();
	test.Close();
	}


TInt E32Main()
	{
	__UHEAP_MARK;
	CTrapCleanup* tc = CTrapCleanup::New(); // Install exception handler
	CActiveScheduler* as = new CActiveScheduler;
	if (!as) 
		Panic(EProblemCreatingScheduler);
	CActiveScheduler::Install(as); // Install active scheduler

	TRAPD(err, RunTestsL());
	if (err != KErrNone)
		Panic(EProblemFindingThreads);

	delete as;
	delete tc;
	__UHEAP_MARKEND;
	return err;
	}

