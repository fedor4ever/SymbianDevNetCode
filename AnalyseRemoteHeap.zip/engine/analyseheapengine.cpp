#include "analyseheapengine.h"
#include <e32const.h>
#include <e32base.h>
#include <e32debug.h>
#include <f32file.h>

//#define RDEBUG_DEBUGS
#ifdef RDEBUG_DEBUGS
#define AH_DEBUG(a) RDebug::Print(_L(a))
#define AH_DEBUGINT(a,b) RDebug::Print(_L(a), b)
#else
#define AH_DEBUG(a) 
#define AH_DEBUGINT(a,b) 
#endif

//#define UDEB_E32
//#define UREL_E32

// Turn on the following block to assume we have a UREL allocator even if we're UDEB
// on target.
//#if (!defined __WINS__ && !defined UDEB_E32)
//#define UREL_E32
//#endif

EXPORT_C CHeapAnalyser* CHeapAnalyser::NewL()
	{
	CHeapAnalyser* self = new(ELeave) CHeapAnalyser;
	CleanupStack::PushL(self);
	self->ConstructL();
	CleanupStack::Pop();
	return self;
	}

CHeapAnalyser::CHeapAnalyser()
	{
	}

void CHeapAnalyser::ConstructL()
	{
	AH_DEBUG("Loading driver");
	TInt err = RMemoryAccess::LoadDriver();
	AH_DEBUG("Loaded driver, opening handle");
	if (err != KErrAlreadyExists)
		User::LeaveIfError(err);
	User::LeaveIfError(iMemoryAccess.Open());
	AH_DEBUG("Opened handle");
	}

EXPORT_C CHeapAnalyser::~CHeapAnalyser()
	{
	AH_DEBUG("Closing handle");
	iMemoryAccess.Close();
	AH_DEBUG("Closed handle, closing driver");
	RMemoryAccess::CloseDriver();
	AH_DEBUG("Closed driver");
	}
	
_LIT(KLitUnderscore, "_");
_LIT(KLitHeap, ".heap");
_LIT(KLitDash, "-");
_LIT(KLitIllegals, ":@[]{}%");
	
EXPORT_C void CHeapAnalyser::DumpHeapToSuitableFileInDirectoryL(TUint aThreadId, const TFileName& aDirectoryName)
	{
	AH_DEBUG("Dumping to file");
	RThread theThread;
	User::LeaveIfError(theThread.Open(aThreadId));
	CleanupClosePushL(theThread);
	AH_DEBUG("Opened thread");
	// create a filename <location>\threadName_threadId.heap
	TFileName theFileName(aDirectoryName);
	const TInt fullNameLengthToTake = aDirectoryName.MaxLength() - aDirectoryName.Length() - KLitHeap().Length() - KLitUnderscore().Length() - 4; // 4 for thread ID number
	TFullName cleanedName = theThread.FullName().Left(fullNameLengthToTake);
	for (TInt whichIllegal = 0;whichIllegal < KLitIllegals().Length(); whichIllegal++)
		{
		TChar thisIllegal = KLitIllegals()[whichIllegal];
		TInt where;
		while ((where = cleanedName.Locate(thisIllegal)) != KErrNotFound)
			cleanedName.Replace(where,1,KLitDash());
		}
	theFileName.Append(cleanedName);
	theFileName.Append(KLitUnderscore);
	theFileName.AppendNum(theThread.Id());
	theFileName.Append(KLitHeap);
	RDebug::Print(_L("The filename is %S"), &theFileName);
	CleanupStack::PopAndDestroy(); // theThread
	AH_DEBUG("Constructed filename");
	DumpHeapToFileL(aThreadId, theFileName);
	}

EXPORT_C void CHeapAnalyser::DumpHeapToFileL(TUint aThreadId, const TFileName& aFileName)
	{
	AH_DEBUG("Dumping to arbitrary file");
	// Open the file
	RFs fs;
	User::LeaveIfError(fs.Connect());
	CleanupClosePushL(fs);
	AH_DEBUG("Connected to F32");
	TInt err = fs.Delete(aFileName);
	if (err != KErrNotFound && err != KErrNone)
		User::Leave(err);
	AH_DEBUG("File deleted");
	RFile f;
	User::LeaveIfError(f.Create(fs,aFileName,EFileWrite));
	CleanupClosePushL(f);
	AH_DEBUG("File created");
	DumpHeapL(aThreadId,f);
	AH_DEBUG("Heap dump appeared to succeed");
	User::LeaveIfError(f.Flush());
	AH_DEBUG("File flushed");
	CleanupStack::PopAndDestroy(2); // f, fs
	}

class RHackedHeap : public RHeap
	{
public:
	RHackedHeap();
	using RHeap::iFree;
	using RHeap::iTop;
	using RHeap::GetAddress;
	using RAllocator::iCellCount;
	using RAllocator::iTotalAllocSize;
	};
	
RHackedHeap::RHackedHeap()
	{
	};
	

EXPORT_C void CHeapAnalyser::DumpHeapL(TUint aThreadId, RFile& aDumpFile)
	{
	// get the thread
	RThread thread;
	AH_DEBUG("Opening thread");
	User::LeaveIfError(thread.Open(aThreadId));
	AH_DEBUG("Opened thread");
	
	THeapDetails heapDetails;
	GetHeapDetailsL(aThreadId, heapDetails);
	
	// write out the heap file in the version 3 format documented in the 'docs' folder.
	
	// 4 bytes: file format version number (Not present for version 1, number found would be heap base & therefore v.big, >1000)	
	TInt version = 3;
	AH_DEBUG("Dumping version");
	User::LeaveIfError(aDumpFile.Write(TPtrC8((TUint8*)&version, 4)));
	
	// 4 bytes: thread ID
	AH_DEBUG("Dumping thread ID");
	User::LeaveIfError(aDumpFile.Write(TPtrC8((TUint8*)&aThreadId, 4)));
	
	// 4 bytes: owning process - appears unused
	AH_DEBUG("Dumping owning process");
	TInt nothing = 0;
	User::LeaveIfError(aDumpFile.Write(TPtrC8((TUint8*)&nothing, 4)));
	
	// 4 bytes: length of thread name
	AH_DEBUG("Dumping thread name length");
	TName threadName = thread.FullName();
	TInt threadNameLength = threadName.Length();
	User::LeaveIfError(aDumpFile.Write(TPtrC8((TUint8*)&threadNameLength, 4)));
	
	// a bytes: thread name
	AH_DEBUG("Dumping thread name");
	HBufC8* asciiName = HBufC8::NewLC(threadNameLength);
	asciiName->Des().Copy(threadName);
	User::LeaveIfError(aDumpFile.Write(*asciiName));
	CleanupStack::PopAndDestroy(asciiName);
	

	// 4 bytes: base address of the heap
	User::LeaveIfError(aDumpFile.Write(TPtrC8((TUint8*)&heapDetails.iBase, 4)));
	// 4 bytes: first free cell address in the heap
	User::LeaveIfError(aDumpFile.Write(TPtrC8((TUint8*)&heapDetails.iFirstFree, 4)));
	// 4 bytes: top address of the heap
	User::LeaveIfError(aDumpFile.Write(TPtrC8((TUint8*)&heapDetails.iTop, 4)));
	// 4 bytes: cell header size
	User::LeaveIfError(aDumpFile.Write(TPtrC8((TUint8*)&heapDetails.iCellHeaderSize, 4)));
	// 4 bytes: heap size (n)
	User::LeaveIfError(aDumpFile.Write(TPtrC8((TUint8*)&heapDetails.iSize, 4)));
	
	// n bytes: heap contents
	// Need to read this across the process boundary
	// We need to copy in several chunks as memoryaccess_eka2 cannot currently
	// copy > 4096 bytes in one go.
	// But this number is not advertised by the memoryaccess_eka2 interface,
	// so we will have to be a bit careful in case it changes in future versions.
	const TInt KChunkSize = 4096;
	AH_DEBUG("Allocating heap storage buffer");
	HBufC8* heapBig = HBufC8::NewLC(KChunkSize);
	TPtr8 myPtr = heapBig->Des();
	TUint8* currentPointer = heapDetails.iBase;
	TUint8* endPointer = currentPointer + heapDetails.iSize;
	TThreadMemoryAccessParams paramsForHeap;
	paramsForHeap.iId = aThreadId;
	while (currentPointer < endPointer)
		{
		AH_DEBUGINT("Copying heap from %08x", (TUint)currentPointer);
		paramsForHeap.iAddr = currentPointer;
		paramsForHeap.iSize = Min(KChunkSize, (endPointer - currentPointer));
		AH_DEBUGINT("Length to copy %d", paramsForHeap.iSize);
		User::LeaveIfError(iMemoryAccess.GetThreadMem(paramsForHeap, myPtr));
		AH_DEBUG("Writing some heap");	
		User::LeaveIfError(aDumpFile.Write(*heapBig));
		currentPointer += heapBig->Length();
		}
	CleanupStack::PopAndDestroy(heapBig);
	
	// Now output the code segment details
	iMemoryAccess.AcquireCodeSegMutex();
	TRAPD(err,DumpCodeSegsL(aDumpFile));
	iMemoryAccess.ReleaseCodeSegMutex();
	User::LeaveIfError(err);
	}
	
void CHeapAnalyser::DumpCodeSegsL(RFile& aDumpFile)
	{
	TCodeSegKernelInfo info;
	TPckg<TCodeSegKernelInfo> infoPckg(info);
	while (iMemoryAccess.GetNextCodeSegInfo(infoPckg))
		{
		// 4 bytes: Code segment run address
		AH_DEBUG("Dumping code seg run address");
		
		User::LeaveIfError(aDumpFile.Write(TPtrC8((TUint8*)&info.iRunAddress, 4)));
		// 4 bytes: Code segment size
		AH_DEBUG("Dumping code seg size");
		User::LeaveIfError(aDumpFile.Write(TPtrC8((TUint8*)&info.iSize, 4)));
		// 4 bytes: Code segment filename length
		AH_DEBUG("Dumping code seg filename length");
		TInt nameLength = info.iFileName.Length();
		User::LeaveIfError(aDumpFile.Write(TPtrC8((TUint8*)&nameLength, 4)));
		// 4 bytes: Code segment filename length
		AH_DEBUG("Dumping code seg filename length");
		User::LeaveIfError(aDumpFile.Write(info.iFileName));
		}
	}

EXPORT_C void CHeapAnalyser::GetHeapDetailsL(TUint aThreadId, THeapDetails& aDetails)
	{
	AH_DEBUG("GetHeapDetailsL");
	AH_DEBUG("Going to try to get allocator address");
	TUint8* allocatorAddress;
	User::LeaveIfError(iMemoryAccess.GetAllocatorAddress(aThreadId, allocatorAddress));
	
	// allocatorAddress now contains the address of the RHeap, in terms
	// of the process address space of aThreadId.
	// We can't read that memory directly.
	
	AH_DEBUG("Got allocator address. Going to try to read...");
	TThreadMemoryAccessParams params;
	params.iId = aThreadId;
	params.iAddr = allocatorAddress;
	params.iSize = sizeof(RHackedHeap);
	RHackedHeap heap;
	TPckg<RHackedHeap> heapPckg(heap);
	User::LeaveIfError(iMemoryAccess.GetThreadMem(params, heapPckg));
	AH_DEBUG("Have copied RHeap from their process to ours");
	
	
	// Base address of the heap
	aDetails.iBase = heap.Base(); // inline, returns member variable
	AH_DEBUGINT("Base is %08x", (TUint)aDetails.iBase);
	// First free cell address in the heap
	aDetails.iFirstFree = (TUint8*)heap.iFree.next; // direct read from member variable
	AH_DEBUGINT("First free is %08x", (TUint)aDetails.iFirstFree);
	// Top address of the heap
	aDetails.iTop = heap.iTop;
	AH_DEBUGINT("Top is %08x", (TUint)aDetails.iTop);
	// Size of heap
	aDetails.iSize = heap.Size(); // inline, returns member variables (after simple maths)
	AH_DEBUGINT("Size is %d", aDetails.iSize);
	
	// Heap cell header size
	#ifdef UREL_E32
	aDetails.iCellHeaderSize = sizeof(RHeap::SCell*);
	#elif UDEB_E32
	aDetails.iCellHeaderSize = sizeof(RHeap::SDebugCell); // If allocator's UDEB-ness matches ours
	#else // match E32 and our own UDEB/URELness
	aDetails.iCellHeaderSize = RHeap::EAllocCellSize; // If allocator is urel and we're not
	#endif
	AH_DEBUGINT("Heap cell header size is %d", aDetails.iCellHeaderSize);
	
	aDetails.iTotalAllocSize = heap.iTotalAllocSize;
	AH_DEBUGINT("Allocated is %d", aDetails.iTotalAllocSize);

	aDetails.iCellCount = heap.iCellCount;
	AH_DEBUGINT("Cell count is %d", aDetails.iCellCount);
	
	AH_DEBUGINT("Free is %d", aDetails.FreeSpace());
	
	AH_DEBUG("Finished GetHeapDetailsL");
	}
	
EXPORT_C RMemoryAccess& CHeapAnalyser::GetMemoryAccess()
	{
	return iMemoryAccess;
	}

EXPORT_C void CHeapAnalyser::ResetMemoryAccessTimer()
	{
	iMemoryAccess.ResetTimer();
	}
