// analyseheapengine.h

#ifndef __ANALYSEHEAPENGINE_H__
#define __ANALYSEHEAPENGINE_H__

#include <e32std.h>
#include <MemoryAccess.h>
#include <f32file.h>

/** Structure with details about a heap, as returned by CHeapAnalyser::GetHeapDetailsL.
*/

class THeapDetails
	{
public:
	/** Base address of the heap. Not very useful. */
	TUint8* iBase;
	/** First free cell on the heap. Not very useful either. */
	TUint8* iFirstFree;
	/** Top address of the heap. Not very useful. */
	TUint8* iTop;
	/** Size of heap. This includes free space. */
	TInt iSize;
	/** Size of a heap cell header. This is not directly useful, but is necessary
	    when calculating the amount of free space. */
	TInt iCellHeaderSize;
	/** Total allocated space in the heap. This excludes cell headers. */
	TInt iTotalAllocSize;
	/** Number of allocated cells on the heap. */
	TInt iCellCount;
	/** Returns the amount of free space on the heap. This is the size of the heap,
	    minus the free space, minus the space occupied by the heap cell headers. */
	inline TInt FreeSpace() 
		{
		return iSize - iTotalAllocSize - (iCellHeaderSize * iCellCount);
		}
	};

class CHeapAnalyser
	{
public:
	IMPORT_C static CHeapAnalyser* NewL();
	IMPORT_C ~CHeapAnalyser();
protected:
	CHeapAnalyser();
	void ConstructL();

public:
	/** Three alternative functions to dump heap information into a file.
	    Use DumpHeapL if you have a writable filehandle to dump it into.
	    Use DumpHeapToFileL if you have a filename to which you wish to 
	    write the information.
	    Use DumpHeapToSuitableFileInDirectoryL if you have a directory name;
	    a file will be created in that directory with a name related to the
	    thread's name.
	    In all cases, a .dump file will be written, which can be analysed
	    using the PC-side "AnalyseHeap" tool to produce an HTML representation
	    of every object in the thread's heap.
	    
	    You may wonder why we pass a thread ID, rather than, for example,
	    a heap ID. The reason is that there is no such thing as a chunk ID.
	    Heaps are entirely user-side structures, which we must access by
	    guessing the type of the object used to perform allocations in a
	    given thread.
	    
	    So, there's currently no way to access the heap stored in an
	    arbitrary chunk, such as the font and bitmap server shared chunk.
	    
	    @param aThreadId The ID of the thread whose heap we wish to dump.
	    */
	IMPORT_C void DumpHeapL(TUint aThreadId, RFile& aFile);
	IMPORT_C void DumpHeapToFileL(TUint aThreadId, const TFileName& aFileName);
	IMPORT_C void DumpHeapToSuitableFileInDirectoryL(TUint aThreadId, const TFileName& aDirectoryName);
	
	/** This function returns some basic facts about the heap of a thread.
	    The only really useful fact is the size.*/
	IMPORT_C void GetHeapDetailsL(TUint aThreadId, THeapDetails& aDetails);
	
	/** This resets the timer of the underlying memoryaccess object. The timer
	    exists to discourage you from leaving the object in a release ROM - 
	    it will reboot the device unless you kick this timer frequently - 
	    every 3 minutes or less.
	    */
	IMPORT_C void ResetMemoryAccessTimer();
	
	/** This gives you access to the underlying RMemoryAccess object, in case
	    you want to do something more sophisticated with it. */
	IMPORT_C RMemoryAccess& GetMemoryAccess();

private:
	void DumpCodeSegsL(RFile& aFile);

protected:
	RMemoryAccess iMemoryAccess;
	};

#endif // __ANALYSEHEAPENGINE_H__
